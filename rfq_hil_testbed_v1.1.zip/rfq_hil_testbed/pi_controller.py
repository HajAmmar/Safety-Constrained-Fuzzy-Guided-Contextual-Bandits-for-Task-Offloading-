#!/usr/bin/env python3
"""Raspberry Pi controller under test (hardware-in-the-loop client).

Runs the scheduler, the Local workload executor, telemetry and Pi-clock timing. Connects to the host
orchestrator over TCP and serves tasks until the host sends BYE.

    python3 pi_controller.py --host 192.168.1.10 --port 5555
"""
import argparse
import hashlib
import json
import os
import random
import select
import socket
import statistics
import sys
import time
import traceback

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from hil import protocol, scheduler as S, telemetry as T, workloads as W  # noqa: E402

STATE_DIR = "pi_state"
LOG_DIR = "pi_logs"


def now_ns():
    return time.perf_counter_ns()


def ms(ns):
    return ns / 1e6

# ---------------------------------------------------------------- workload calibration


def calibrate_workloads(path, label):
    """Median wall time per work unit for each kernel kind on the idle device."""
    if os.path.exists(path):
        with open(path) as f:
            return json.load(f)
    print("[pi] calibrating workload kernels (about 30 s, keep the Pi idle)...", flush=True)
    payload = W.make_payload(1, 65536)
    out = {}
    for kind in W.KINDS:
        W.run_kernel(kind, 5, payload)     # warm-up
        samples = []
        for _ in range(9):
            t0 = now_ns()
            W.run_kernel(kind, 40, payload)
            samples.append(ms(now_ns() - t0) / 40)
        out[kind] = statistics.median(samples)
    out["_device"] = label
    out["_created"] = time.strftime("%Y-%m-%dT%H:%M:%S")
    with open(path, "w") as f:
        json.dump(out, f, indent=1)
    print("[pi] ms per unit:", {k: round(v, 3) for k, v in out.items() if not k.startswith("_")}, flush=True)
    return out


def wait_readable(sock, timeout_s):
    r, _, _ = select.select([sock], [], [], max(0.0, timeout_s))
    return bool(r)

# ---------------------------------------------------------------- controller


class Controller:
    def __init__(self, sock, calib, args):
        self.sock = sock
        self.calib = calib
        self.args = args
        self.cpu = T.CpuSampler()
        self.stress = T.Stressor()
        self.rng = random.Random(0)
        self.q = {}                    # learner name -> QTable (kept in memory across calibration runs)
        self.run = None
        self.log = None
        self.pending = None            # deferred Q transition (state, action, reward) for gamma > 0
        self.stale = 0

    # -------------------------------------------------- run lifecycle
    def on_config(self, h):
        self.run = h
        self.rng = random.Random(h["seed"] * 7919 + 17)
        self.est = S.Estimator({k: v for k, v in self.calib.items() if not k.startswith("_")})
        self.est.rtt = h.get("rtt_prior_ms", 30.0)
        self.pending = None
        pol = h["policy"]
        qhash = None
        if pol in S.LEARNERS:
            name = h.get("q_name", pol)
            path = os.path.join(STATE_DIR, "q_%s.json" % name)
            if h["mode"] == "online":
                if h.get("q_init") == "fresh":
                    self.q[name] = S.QTable()
                elif name not in self.q:          # resume after a restart: continue from the last saved table
                    if os.path.exists(path):
                        with open(path) as f:
                            self.q[name] = S.QTable.from_json(f.read())
                    else:
                        self.q[name] = S.QTable()
            else:  # frozen: load the archived table from disk
                with open(path) as f:
                    self.q[name] = S.QTable.from_json(f.read())
            self.qt = self.q[name]
            qhash = self.qt.digest()
        else:
            self.qt = None
        self.stress.set(int(h.get("stress", 0)))
        time.sleep(h.get("settle_s", 1.0))
        self.cpu.sample()
        os.makedirs(LOG_DIR, exist_ok=True)
        self.log = open(os.path.join(LOG_DIR, "%s.jsonl" % h["run_id"]), "w")
        self.peak_rss = 0
        protocol.send(self.sock, {"type": "CONFIG_ACK", "run_id": h["run_id"], "q_hash": qhash,
                                  "temp_c": T.temperature_c(), "freq_mhz": T.cpu_freq_mhz(), "throttled": T.throttled()})

    def on_end_run(self, h):
        if self.pending is not None and self.qt is not None:
            s, a, r = self.pending
            self.qt.update(s, a, r, s, self.run["alpha"], 0.0)
            self.pending = None
        self.stress.clear()
        qhash = None
        if self.qt is not None:
            qhash = self.qt.digest()
            if h.get("save_q"):
                os.makedirs(STATE_DIR, exist_ok=True)
                with open(os.path.join(STATE_DIR, "q_%s.json" % h["save_q"]), "w") as f:
                    f.write(self.qt.to_json())
        if self.log:
            self.log.close()
            self.log = None
        m = T.mem_kb()
        protocol.send(self.sock, {"type": "RUN_SUMMARY", "run_id": h["run_id"], "q_hash": qhash,
                                  "q_visited": sum(1 for v in self.qt.visits if v[0] + v[1] > 0) if self.qt else None,
                                  "hwm_kb": m["hwm_kb"], "rss_kb": m["rss_kb"], "temp_c": T.temperature_c(),
                                  "throttled": T.throttled(), "stale_results": self.stale})

    # -------------------------------------------------- probes (link-state observation, same for all policies)
    def on_probe_req(self, h):
        t0 = now_ns()
        protocol.send(self.sock, {"type": "PROBE", "seq": h["seq"]})
        while True:
            hh, _ = protocol.recv(self.sock)
            if hh["type"] == "PROBE_ACK" and hh["seq"] == h["seq"]:
                break
            if hh["type"] == "OFFLOAD_RESULT":
                self.stale += 1        # late result of a timed-out offload: discard
                continue
            raise protocol.ProtocolError("unexpected %s during probe" % hh["type"])
        rtt = ms(now_ns() - t0)
        self.est.obs_rtt(rtt)
        protocol.send(self.sock, {"type": "PROBE_DONE", "seq": h["seq"], "rtt_ms": rtt})

    # -------------------------------------------------- one task
    def on_task(self, h):
        run = self.run
        payload = W.make_payload(h["task_seed"], h["payload_bytes"])     # data acquisition (not timed)
        crc = W.payload_crc(payload)
        t_acc = now_ns()                                                  # task accepted on Pi clock
        cpu = self.cpu.sample()
        temp = T.temperature_c()
        urg = S.urgency(h["deadline_ms"], run["params"]["d_safe_ms"], run["params"]["d_max_ms"])
        ctx = {"cpu": cpu, "rtt": self.est.rtt, "payload_kb": h["payload_bytes"] / 1024.0, "urg": urg,
               "work_cls": h["work_cls"], "payload_cls": h["payload_cls"], "critical": bool(h["critical"]),
               "deadline_ms": h["deadline_ms"], "kind": h["kind"], "units": h["units"],
               "payload_bytes": h["payload_bytes"], "est": self.est}
        eps = run.get("epsilon", 0.0) if run["mode"] == "online" else 0.0
        d = S.decide(run["policy"], ctx, self.qt, run["params"], self.rng, eps)
        t_dec = now_ns()

        # deferred Q update for the previous transition now that the next state is known
        if self.pending is not None and self.qt is not None and run["mode"] == "online":
            s, a, r = self.pending
            self.qt.update(s, a, r, d.state, run["alpha"], run["gamma"])
            self.pending = None

        fallback = False
        timeout = False
        invalid = False
        remote_ms = None
        offload_ms = None
        checksum = None
        if d.action == S.OFFLOAD:
            t_req = now_ns()
            protocol.send(self.sock, {"type": "OFFLOAD_REQUEST", "seq": h["seq"], "kind": h["kind"],
                                      "units": h["units"], "crc": crc}, payload)
            limit_s = run["params"]["offload_timeout_ms"] / 1000.0
            deadline_t = time.perf_counter() + limit_s
            got = None
            while True:
                left = deadline_t - time.perf_counter()
                if left <= 0 or not wait_readable(self.sock, left):
                    timeout = True
                    break
                hh, _ = protocol.recv(self.sock)
                if hh["type"] != "OFFLOAD_RESULT":
                    raise protocol.ProtocolError("unexpected %s while waiting for offload" % hh["type"])
                if hh["seq"] != h["seq"]:
                    self.stale += 1
                    continue
                got = hh
                break
            offload_ms = ms(now_ns() - t_req)
            if got is not None:
                if got.get("status") == "ok" and got.get("crc") == crc and isinstance(got.get("checksum"), str) \
                        and len(got["checksum"]) == 64:
                    checksum = got["checksum"]
                    remote_ms = got.get("remote_ms")
                    self.est.obs_offload(h["kind"], h["units"], h["payload_bytes"], offload_ms, remote_ms)
                else:
                    invalid = True
            else:
                self.est.obs_rtt(offload_ms)            # a timeout is evidence of a degraded link
            if timeout or invalid:
                fallback = True
        local_ms = None
        if d.action == S.LOCAL or fallback:
            t_l = now_ns()
            checksum = W.run_kernel(h["kind"], h["units"], payload)
            local_ms = ms(now_ns() - t_l)
            if not fallback:
                self.est.obs_local(h["kind"], h["units"], cpu, local_ms)
        t_end = now_ns()
        completion = ms(t_end - t_acc)
        missed = completion > h["deadline_ms"]
        r = S.reward(completion, h["deadline_ms"], missed, False, run["weights"])
        learnable = self.qt is not None and d.source == "learner"
        if learnable and run["mode"] == "online":
            if run["gamma"] > 0:
                self.pending = (d.state, d.action, r)
            else:
                self.qt.update(d.state, d.action, r, d.state, run["alpha"], 0.0)
        m = T.mem_kb()
        if m["rss_kb"] and m["rss_kb"] > self.peak_rss:
            self.peak_rss = m["rss_kb"]
        rec = {"type": "FINAL_RESULT", "seq": h["seq"], "action": S.ACTIONS[d.action], "source": d.source,
               "explored": d.explored, "fallback": fallback, "timeout": timeout, "invalid": invalid,
               "state": d.state, "cpu": round(cpu, 2), "rtt_est_ms": round(ctx["rtt"], 3), "urg": round(urg, 4),
               "temp_c": temp, "fuzzy": d.fuzzy, "qvals": d.qvals,
               "guard_us": d.guard_ns / 1e3, "fuzzy_us": d.fuzzy_ns / 1e3, "q_us": d.q_ns / 1e3,
               "decision_us": (t_dec - t_acc) / 1e3, "policy_us": d.total_ns / 1e3,
               "local_ms": local_ms, "offload_ms": offload_ms, "remote_ms": remote_ms,
               "completion_ms": completion, "missed": missed, "checksum": checksum, "reward": r,
               "rss_kb": m["rss_kb"]}
        self.log.write(json.dumps(rec) + "\n")
        protocol.send(self.sock, rec)

    # -------------------------------------------------- isolated layer profiling
    def on_profile(self, h):
        self.stress.clear()
        n = int(h.get("n", 20000))
        rng = random.Random(99)
        params = h["params"]
        est = S.Estimator({k: v for k, v in self.calib.items() if not k.startswith("_")})
        qt = S.QTable([[rng.uniform(-1, 0), rng.uniform(-1, 0)] for _ in range(S.N_STATES)])
        ctxs = []
        for _ in range(n):
            ctxs.append({"cpu": rng.uniform(0, 100), "rtt": rng.uniform(0, 300), "payload_kb": rng.uniform(0, 256),
                         "urg": rng.random(), "work_cls": rng.randrange(3), "payload_cls": rng.randrange(3),
                         "critical": False, "deadline_ms": 1e9, "kind": "cpu", "units": 10,
                         "payload_bytes": 65536, "est": est})
        res = {}
        m0 = T.mem_kb()
        for pol in S.POLICIES:
            for c in ctxs[:500]:
                S.decide(pol, c, qt, params, rng)          # warm-up
            tot, fz, qq = [], [], []
            for c in ctxs:
                d = S.decide(pol, c, qt, params, rng)
                tot.append(d.total_ns / 1e3)
                fz.append(d.fuzzy_ns / 1e3)
                qq.append(d.q_ns / 1e3)
            res[pol] = {"total_us": _pct(tot), "fuzzy_us": _pct(fz), "q_us": _pct(qq)}
        upd = []
        for c in ctxs:
            s = S.state_index(c["cpu"], c["rtt"], c["work_cls"], c["payload_cls"], c["urg"])
            t0 = now_ns()
            qt.update(s, rng.randrange(2), -0.5, s, 0.1, 0.0)
            upd.append((now_ns() - t0) / 1e3)
        res["Q-update"] = {"total_us": _pct(upd)}
        fz = []
        for c in ctxs:
            t0 = now_ns()
            S.fuzzy_score(c["cpu"], c["rtt"], c["payload_kb"], c["urg"])
            fz.append((now_ns() - t0) / 1e3)
        res["FIS-81"] = {"total_us": _pct(fz)}
        m1 = T.mem_kb()
        out = {"type": "PROFILE_RESULT", "n": n, "layers": res, "rss_kb_before": m0["rss_kb"], "rss_kb_after": m1["rss_kb"],
               "hwm_kb": m1["hwm_kb"], "q_table_values": S.N_STATES * 2, "q_table_json_bytes": len(qt.to_json()),
               "temp_c": T.temperature_c(), "freq_mhz": T.cpu_freq_mhz(), "throttled": T.throttled()}
        protocol.send(self.sock, out)

    def serve(self):
        try:
            while True:
                h, _ = protocol.recv(self.sock)
                t = h["type"]
                if t == "CONFIG":
                    self.on_config(h)
                elif t == "TASK":
                    self.on_task(h)
                elif t == "PROBE_REQ":
                    self.on_probe_req(h)
                elif t == "END_RUN":
                    self.on_end_run(h)
                elif t == "PROFILE_REQ":
                    self.on_profile(h)
                elif t == "OFFLOAD_RESULT":
                    self.stale += 1
                elif t == "BYE":
                    print("[pi] host finished; exiting.", flush=True)
                    return True
                else:
                    raise protocol.ProtocolError("unexpected message %s" % t)
        finally:
            self.stress.clear()


def _pct(xs):
    xs = sorted(xs)
    n = len(xs)
    return {"mean": sum(xs) / n, "median": xs[n // 2], "p95": xs[int(0.95 * (n - 1))],
            "p99": xs[int(0.99 * (n - 1))], "max": xs[-1], "n": n}


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--host", required=True, help="IP address of the host computer")
    ap.add_argument("--port", type=int, default=5555)
    ap.add_argument("--role-label", default="raspberry-pi", help="label stored with the run (keep default on the Pi)")
    args = ap.parse_args()
    os.makedirs(STATE_DIR, exist_ok=True)
    hw = T.hardware_identity()
    calib = calibrate_workloads(os.path.join(STATE_DIR, "calibration.json"), hw.get("model"))
    while True:
        try:
            sock = protocol.tune(socket.create_connection((args.host, args.port), timeout=10))
            sock.settimeout(None)
        except OSError as e:
            print("[pi] waiting for host %s:%d (%s)" % (args.host, args.port, e), flush=True)
            time.sleep(3)
            continue
        print("[pi] connected to host", flush=True)
        qfiles = {}
        if os.path.isdir(STATE_DIR):
            for fn in sorted(os.listdir(STATE_DIR)):
                if fn.startswith("q_") and fn.endswith(".json"):
                    with open(os.path.join(STATE_DIR, fn)) as f:
                        qfiles[fn[2:-5]] = S.QTable.from_json(f.read()).digest()
        protocol.send(sock, {"type": "HELLO", "role": args.role_label, "hw": hw, "calibration": calib,
                             "q_tables": qfiles, "scheduler_sha256": _file_hash(S.__file__),
                             "workloads_sha256": _file_hash(W.__file__)})
        ctl = Controller(sock, calib, args)
        try:
            if ctl.serve():
                return
        except (ConnectionError, OSError, protocol.ProtocolError) as e:
            print("[pi] connection lost (%s); reconnecting..." % e, flush=True)
            traceback.print_exc()
            time.sleep(2)
        finally:
            sock.close()


def _file_hash(p):
    with open(p, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


if __name__ == "__main__":
    main()
