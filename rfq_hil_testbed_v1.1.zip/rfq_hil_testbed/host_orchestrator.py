#!/usr/bin/env python3
"""Host orchestrator: seeded task generation, network impairment, remote (Offload) execution,
host-clock timing and the authoritative run log. Waits for the Raspberry Pi to connect.

    python host_orchestrator.py --phase all              # full campaign (resumable)
    python host_orchestrator.py --profile pilot --phase all   # 10-minute pilot run
    python host_orchestrator.py --phase energy           # optional USB-meter energy blocks

Completed runs are skipped automatically, so the command can simply be re-run after an interruption.
"""
import argparse
import hashlib
import json
import os
import random
import socket
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from hil import protocol, scheduler as S, telemetry as T, workloads as W  # noqa: E402

PHASES = ("profile", "calibration", "main", "faults")


def now_ns():
    return time.perf_counter_ns()


def file_hash(p):
    with open(p, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()

# ---------------------------------------------------------------- network impairment (application level)


class Net:
    def __init__(self, regime, cfg, rng, rto_ms):
        self.cfg = cfg
        self.rng = rng
        self.rto = rto_ms
        self.bad = False
        self.name = regime
        self.fault = None

    def step(self):
        c = self.cfg
        if "bad" in c:
            if self.bad:
                self.bad = self.rng.random() >= c["p_bad_to_good"]
            else:
                self.bad = self.rng.random() < c["p_good_to_bad"]

    def _cur(self):
        return self.cfg["bad"] if (self.bad and "bad" in self.cfg) else self.cfg

    def delay_ms(self, payload_bytes, rng):
        """rng is seeded per (task, purpose) so every policy sees the same draws for the same task."""
        c = self._cur()
        d = max(0.0, rng.gauss(c["rtt_ms"], c["jitter_ms"]))
        d += payload_bytes * 8 / (c["mbps"] * 1000.0)
        loss = c["loss"]
        if self.fault and self.fault[0] == "loss_burst":
            loss = max(loss, self.fault[1]["loss"])
        if loss > 0 and rng.random() < loss:
            d += self.rto
        if self.fault and self.fault[0] == "outage":
            d += self.fault[1]["extra_delay_ms"]
        return d

# ---------------------------------------------------------------- task generation (identical for all policies)


def make_tasks(cfg, seed, cond_key, calib, n):
    tm = cfg["task_model"]
    rng = random.Random("%s|%s" % (seed, cond_key))
    tasks = []
    for i in range(n):
        kind = rng.choice(W.KINDS)
        wc = rng.randrange(3)
        pc = rng.randrange(3)
        target = tm["work_target_ms"][wc]
        units = max(1, int(round(target / calib[kind])))
        pbytes = int(tm["payload_bytes"][pc] * rng.uniform(0.75, 1.25))
        critical = rng.random() < tm["critical_prob"]
        pressure = rng.choice(("relaxed", "moderate", "strict"))
        deadline = target * tm["deadline_factor"][pressure] + tm["deadline_offset_ms"]
        urgent = rng.random() < tm["urgent_prob"]
        if urgent:
            deadline = rng.uniform(10.0, cfg["params"]["d_safe_ms"])
        tasks.append({"seq": i, "task_seed": rng.getrandbits(48), "kind": kind, "work_cls": wc, "units": units,
                      "payload_cls": pc, "payload_bytes": pbytes, "critical": int(critical),
                      "pressure": "urgent" if urgent else pressure, "deadline_ms": round(deadline, 3)})
    return tasks

# ---------------------------------------------------------------- orchestrator


class Host:
    def __init__(self, args, cfg):
        self.args = args
        self.cfg = cfg
        self.out = args.out
        os.makedirs(os.path.join(self.out, "runs"), exist_ok=True)
        self.sock = None
        self.hello = None

    # -------------------------------------------------- connection
    def accept(self):
        srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        srv.bind(("0.0.0.0", self.args.port))
        srv.listen(1)
        print("[host] listening on port %d - start pi_controller.py on the Raspberry Pi" % self.args.port, flush=True)
        conn, addr = srv.accept()
        srv.close()
        self.sock = protocol.tune(conn)
        h, _ = protocol.recv(self.sock)
        if h["type"] != "HELLO":
            raise protocol.ProtocolError("expected HELLO")
        self.hello = h
        self.hello["peer_ip"] = addr[0]
        mine = {"scheduler_sha256": file_hash(S.__file__), "workloads_sha256": file_hash(W.__file__)}
        for k, v in mine.items():
            if h.get(k) != v:
                raise SystemExit("[host] %s differs between host and Pi - copy the same package to both devices." % k)
        print("[host] connected: %s (%s)" % (h["hw"].get("model"), addr[0]), flush=True)
        self.calib = {k: v for k, v in h["calibration"].items() if not k.startswith("_")}
        with open(os.path.join(self.out, "environment.json"), "w") as f:
            json.dump({"pi": h, "host": T.hardware_identity(), "host_hostname": socket.gethostname(),
                       "config": self.cfg, "package": mine,
                       "label": "physical-hil" if addr[0] not in ("127.0.0.1", "::1") else "software-loopback",
                       "started": time.strftime("%Y-%m-%dT%H:%M:%S")}, f, indent=1)

    def done(self, run_id):
        return os.path.exists(os.path.join(self.out, "runs", run_id + ".jsonl"))

    # -------------------------------------------------- one run
    def run(self, run_id, phase, policy, mode, seed, load, net_name, extra=None, n_tasks=None, fault=None):
        cfg = self.cfg
        extra = extra or {}
        n = n_tasks or cfg["tasks_per_run"]
        tasks = make_tasks(cfg, seed, "%s|%s" % (load, net_name), self.calib, n)
        net = Net(net_name, cfg["network_regimes"][net_name], random.Random("net|%s|%s|%s" % (seed, load, net_name)),
                  cfg["loss_rto_ms"])
        conf = {"type": "CONFIG", "run_id": run_id, "phase": phase, "policy": policy, "mode": mode, "seed": seed,
                "stress": cfg["load_levels"][load], "settle_s": cfg["settle_s"], "params": cfg["params"],
                "weights": cfg["weights"], "alpha": cfg["learning"]["alpha"], "gamma": cfg["learning"]["gamma"],
                "rtt_prior_ms": 30.0}
        conf.update(extra)
        tmp = os.path.join(self.out, "runs", run_id + ".jsonl.tmp")
        f = open(tmp, "w")
        protocol.send(self.sock, conf)
        ack, _ = protocol.recv(self.sock)
        if ack["type"] != "CONFIG_ACK":
            raise protocol.ProtocolError("expected CONFIG_ACK")
        f.write(json.dumps({"rec": "config", "load": load, "net": net_name, "fault": fault, **conf, "ack": ack}) + "\n")
        integrity = {"guard_violations": 0, "checksum_mismatch": 0, "seq_errors": 0}
        t_run = time.perf_counter()
        for t in tasks:
            net.step()
            if fault:
                lo, hi = (int(round(x * n)) for x in cfg["faults"]["window_frac"])
                net.fault = (fault, cfg["faults"]["types"][fault]) if lo <= t["seq"] < hi else None
            if t["seq"] % cfg["probe_every"] == 0:
                protocol.send(self.sock, {"type": "PROBE_REQ", "seq": t["seq"]})
                h, _ = protocol.recv(self.sock)
                if h["type"] != "PROBE":
                    raise protocol.ProtocolError("expected PROBE")
                time.sleep(net.delay_ms(64, random.Random("probe|%d|%s|%s|%d" % (seed, load, net_name, t["seq"]))) / 1000.0)
                protocol.send(self.sock, {"type": "PROBE_ACK", "seq": t["seq"]})
                h, _ = protocol.recv(self.sock)
                if h["type"] != "PROBE_DONE":
                    raise protocol.ProtocolError("expected PROBE_DONE")
            guarded = bool(t["critical"]) or t["deadline_ms"] <= cfg["params"]["d_safe_ms"]
            t0 = now_ns()
            protocol.send(self.sock, {"type": "TASK", **t})
            hrec = {"offloaded": False, "net_bad": net.bad, "fault_active": net.fault is not None}
            while True:
                h, payload = protocol.recv(self.sock)
                if h["type"] == "OFFLOAD_REQUEST":
                    if h["seq"] != t["seq"]:
                        integrity["seq_errors"] += 1
                    if guarded and policy != "Offload-All":
                        integrity["guard_violations"] += 1
                    r0 = now_ns()
                    chk = W.run_kernel(h["kind"], h["units"], payload)
                    remote_ms = (now_ns() - r0) / 1e6
                    status, crc = "ok", W.payload_crc(payload)
                    if net.fault and net.fault[0] == "host_slowdown":
                        time.sleep(remote_ms * (net.fault[1]["remote_factor"] - 1.0) / 1000.0)
                        remote_ms *= net.fault[1]["remote_factor"]
                    if net.fault and net.fault[0] == "corrupt" and \
                            random.Random("corrupt|%d|%d" % (seed, t["seq"])).random() < net.fault[1]["prob"]:
                        crc = (crc + 1) & 0xFFFFFFFF
                    imp = net.delay_ms(len(payload), random.Random("off|%d|%s|%s|%d" % (seed, load, net_name, t["seq"])))
                    time.sleep(imp / 1000.0)
                    protocol.send(self.sock, {"type": "OFFLOAD_RESULT", "seq": h["seq"], "status": status, "crc": crc,
                                              "checksum": chk, "remote_ms": remote_ms})
                    hrec.update({"offloaded": True, "host_checksum": chk, "host_remote_ms": remote_ms,
                                 "impairment_ms": imp, "payload_rx_bytes": len(payload)})
                elif h["type"] == "FINAL_RESULT":
                    if h["seq"] != t["seq"]:
                        integrity["seq_errors"] += 1
                    hrec["host_loop_ms"] = (now_ns() - t0) / 1e6
                    if hrec.get("host_checksum") and h.get("checksum") and not h.get("fallback") \
                            and h["checksum"] != hrec["host_checksum"]:
                        integrity["checksum_mismatch"] += 1
                    f.write(json.dumps({"rec": "task", "task": t, "guarded": guarded, "host": hrec, "pi": h}) + "\n")
                    break
                else:
                    raise protocol.ProtocolError("unexpected %s during task" % h["type"])
        protocol.send(self.sock, {"type": "END_RUN", "run_id": run_id, "save_q": extra.get("save_q")})
        while True:
            summ, _ = protocol.recv(self.sock)
            if summ["type"] == "RUN_SUMMARY":
                break
        wall = time.perf_counter() - t_run
        f.write(json.dumps({"rec": "summary", "integrity": integrity, "wall_s": wall, "pi": summ}) + "\n")
        f.close()
        final = tmp[:-4]
        os.replace(tmp, final)
        with open(os.path.join(self.out, "manifest.jsonl"), "a") as m:
            m.write(json.dumps({"run_id": run_id, "sha256": file_hash(final), "bytes": os.path.getsize(final),
                                "finished": time.strftime("%Y-%m-%dT%H:%M:%S")}) + "\n")
        bad = sum(integrity.values())
        print("[host] %-55s %5.1fs  T=%s  integrity=%s" % (run_id, wall, summ.get("temp_c"), "OK" if bad == 0 else integrity),
              flush=True)
        time.sleep(self.cfg["cooldown_s"])

    # -------------------------------------------------- phases
    def conditions(self):
        return [(l, n) for l in self.cfg["load_levels"] for n in self.cfg["network_regimes"]]

    def phase_profile(self):
        p = os.path.join(self.out, "profile.json")
        if os.path.exists(p):
            return
        print("[host] isolated controller profiling on the Pi...", flush=True)
        protocol.send(self.sock, {"type": "PROFILE_REQ", "n": 20000, "params": self.cfg["params"]})
        h, _ = protocol.recv(self.sock)
        with open(p, "w") as f:
            json.dump(h, f, indent=1)

    def phase_calibration(self):
        cfg = self.cfg
        lr = cfg["learning"]
        for learner in S.LEARNERS:
            order = [(s, l, n) for s in cfg["seeds"]["calibration"] for (l, n) in self.conditions()]
            random.Random("calib|" + learner).shuffle(order)
            total = len(order)
            for i, (s, l, n) in enumerate(order):
                rid = "calib_%s_s%d_%s_%s" % (learner, s, l, n)
                if self.done(rid):
                    continue
                eps = lr["eps_start"] + (lr["eps_end"] - lr["eps_start"]) * i / max(1, total - 1)
                self.run(rid, "calibration", learner, "online", s, l, n,
                         extra={"q_name": learner + self.args.qsuffix, "q_init": "fresh" if i == 0 else "continue",
                                "epsilon": eps, "save_q": learner + self.args.qsuffix})

    def phase_main(self):
        for s in self.cfg["seeds"]["evaluation"]:
            conds = self.conditions()
            random.Random("cond|%d" % s).shuffle(conds)
            for (l, n) in conds:
                pols = list(S.POLICIES)
                random.Random("pol|%d|%s|%s" % (s, l, n)).shuffle(pols)
                for p in pols:
                    rid = "main_%s_s%d_%s_%s" % (p, s, l, n)
                    if not self.done(rid):
                        self.run(rid, "main", p, "frozen", s, l, n, extra={"q_name": p + self.args.qsuffix})

    def phase_faults(self):
        l, n = self.cfg["faults"]["condition"]
        for fault in self.cfg["faults"]["types"]:
            for s in self.cfg["seeds"]["faults"]:
                pols = list(S.POLICIES)
                random.Random("fpol|%s|%d" % (fault, s)).shuffle(pols)
                for p in pols:
                    rid = "fault-%s_%s_s%d_%s_%s" % (fault, p, s, l, n)
                    if not self.done(rid):
                        self.run(rid, "faults", p, "frozen", s, l, n, extra={"q_name": p + self.args.qsuffix}, fault=fault)

    def phase_energy(self):
        e = self.cfg["energy"]
        l, n = e["condition"]
        path = os.path.join(self.out, "energy_readings.jsonl")
        print("\n[host] ENERGY BLOCKS: read the cumulative energy (mWh) on the USB power meter when asked.\n", flush=True)
        blocks = ["IDLE"] + list(S.POLICIES)
        done = set()
        if os.path.exists(path):
            done = {json.loads(x)["block"] for x in open(path)}
        for b in blocks:
            if b in done:
                continue
            before = float(input("[host] block %s - enter meter reading in mWh NOW, then press Enter: " % b))
            t0 = time.time()
            if b == "IDLE":
                time.sleep(e["idle_s"])
                rid = None
            else:
                rid = "energy_%s_%s_%s" % (b, l, n)
                self.run(rid, "energy", b, "frozen", 300, l, n, extra={"q_name": b + self.args.qsuffix}, n_tasks=e["tasks"])
            dur = time.time() - t0
            after = float(input("[host] block %s finished - enter meter reading in mWh NOW: " % b))
            with open(path, "a") as f:
                f.write(json.dumps({"block": b, "run_id": rid, "mwh_before": before, "mwh_after": after,
                                    "duration_s": dur}) + "\n")

    def bye(self):
        try:
            protocol.send(self.sock, {"type": "BYE"})
        except OSError:
            pass


def load_cfg(path, profile):
    with open(path) as f:
        cfg = json.load(f)
    if profile:
        for k, v in cfg["profiles"][profile].items():
            cfg[k] = v
    return cfg


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--config", default=os.path.join(os.path.dirname(os.path.abspath(__file__)), "config", "experiment.json"))
    ap.add_argument("--profile", default=None, help="'pilot' for a short trial campaign")
    ap.add_argument("--phase", default="all", help="all | profile | calibration | main | faults | energy")
    ap.add_argument("--port", type=int, default=5555)
    ap.add_argument("--out", default=None)
    args = ap.parse_args()
    cfg = load_cfg(args.config, args.profile)
    args.out = args.out or ("results_" + (args.profile or "campaign"))
    args.qsuffix = "-" + args.profile if args.profile else ""
    phases = PHASES if args.phase == "all" else (args.phase,)
    while True:
        host = Host(args, cfg)
        try:
            host.accept()
            for ph in phases:
                getattr(host, "phase_" + ph)()
            host.bye()
            print("[host] all requested phases complete. Results are in %s/" % args.out, flush=True)
            return
        except (ConnectionError, OSError, protocol.ProtocolError) as e:
            print("[host] connection problem (%s). Waiting for the Pi to reconnect; completed runs are kept." % e, flush=True)
            for fn in os.listdir(os.path.join(args.out, "runs")):
                if fn.endswith(".tmp"):
                    os.remove(os.path.join(args.out, "runs", fn))
            time.sleep(1)


if __name__ == "__main__":
    main()
