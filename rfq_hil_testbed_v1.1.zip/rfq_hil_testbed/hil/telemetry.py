"""Device telemetry for Linux / Raspberry Pi OS (falls back to neutral values elsewhere)."""
import multiprocessing as mp
import os
import platform
import subprocess


def _read(path):
    try:
        with open(path) as f:
            return f.read()
    except OSError:
        return None


class CpuSampler:
    """System-wide CPU utilization (%) over the interval since the previous call, from /proc/stat."""

    def __init__(self):
        self.prev = self._snap()

    @staticmethod
    def _snap():
        s = _read("/proc/stat")
        if not s:
            return None
        f = [int(x) for x in s.splitlines()[0].split()[1:]]
        idle = f[3] + (f[4] if len(f) > 4 else 0)
        return sum(f), idle

    def sample(self):
        cur = self._snap()
        if cur is None or self.prev is None:
            return 0.0
        dt, di = cur[0] - self.prev[0], cur[1] - self.prev[1]
        self.prev = cur
        return 100.0 * (1.0 - di / dt) if dt > 0 else 0.0


def temperature_c():
    s = _read("/sys/class/thermal/thermal_zone0/temp")
    return int(s) / 1000.0 if s else None


def cpu_freq_mhz():
    s = _read("/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq")
    return int(s) / 1000.0 if s else None


def mem_kb():
    s = _read("/proc/self/status")
    out = {"rss_kb": None, "hwm_kb": None}
    if s:
        for line in s.splitlines():
            if line.startswith("VmRSS:"):
                out["rss_kb"] = int(line.split()[1])
            elif line.startswith("VmHWM:"):
                out["hwm_kb"] = int(line.split()[1])
    return out


def throttled():
    """Raspberry Pi firmware throttling flags (hex string) or None if vcgencmd is unavailable."""
    try:
        r = subprocess.run(["vcgencmd", "get_throttled"], capture_output=True, text=True, timeout=2)
        return r.stdout.strip().split("=")[-1] if r.returncode == 0 else None
    except (OSError, subprocess.SubprocessError):
        return None


def hardware_identity():
    info = {"platform": platform.platform(), "machine": platform.machine(), "python": platform.python_version(),
            "cpu_count": os.cpu_count()}
    model = _read("/proc/device-tree/model")
    info["model"] = model.strip("\x00\n ") if model else platform.node()
    gov = _read("/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor")
    info["governor"] = gov.strip() if gov else None
    mi = _read("/proc/meminfo")
    if mi:
        info["mem_total_kb"] = int(mi.splitlines()[0].split()[1])
    info["kernel"] = platform.release()
    return info

# ---------------------------------------------------------------- background load (workload intensity)


def _burn(stop):
    x = 0
    while not stop.is_set():
        for _ in range(20000):
            x = (x * 1103515245 + 12345) & 0x7FFFFFFF


class Stressor:
    def __init__(self):
        self.procs = []
        self.stop = None

    def set(self, n):
        self.clear()
        if n <= 0:
            return
        self.stop = mp.Event()
        for _ in range(n):
            p = mp.Process(target=_burn, args=(self.stop,), daemon=True)
            p.start()
            self.procs.append(p)

    def clear(self):
        if self.stop is not None:
            self.stop.set()
        for p in self.procs:
            p.join(timeout=2)
            if p.is_alive():
                p.terminate()
        self.procs, self.stop = [], None
