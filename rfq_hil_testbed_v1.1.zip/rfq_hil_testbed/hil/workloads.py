"""Deterministic workload kernels executed identically on the Raspberry Pi (Local) and the host (Offload).

A task is fully described by (kind, units, payload). The kernel returns a SHA-256 checksum, so the
same task executed on either endpoint must return the same value; the analysis script uses this to
verify workload equivalence across policies.
"""
import hashlib
import random
import zlib

KINDS = ("cpu", "mem", "mixed")
_MEM_BYTES = 4 << 20      # 4 MiB working buffer for the memory-bound kernel
_CHUNK = 64 << 10         # 64 KiB copy granularity


def make_payload(task_seed, size):
    """Sensor payload generated on the device from the task seed (stands in for acquired data)."""
    return random.Random(task_seed).randbytes(size)


def payload_crc(payload):
    return zlib.crc32(payload) & 0xFFFFFFFF


def _cpu_unit(state, block):
    # 32 chained SHA-256 digests over a 4 KiB block derived from the payload
    for _ in range(32):
        state = hashlib.sha256(state + block).digest()
    return state


_mem_cache = {}


def _mem_buffer():
    b = _mem_cache.get("buf")
    if b is None:
        b = bytearray(random.Random(12345).randbytes(_MEM_BYTES))
        _mem_cache["buf"] = b
    return b


def _mem_unit(state, buf, rng):
    # 16 pseudo-random 64 KiB block copies (1 MiB moved) followed by a digest of one block
    n = _MEM_BYTES // _CHUNK
    for _ in range(16):
        a = rng.randrange(n) * _CHUNK
        b = rng.randrange(n) * _CHUNK
        buf[a:a + _CHUNK] = buf[b:b + _CHUNK]
    a = rng.randrange(n) * _CHUNK
    return hashlib.sha256(state + bytes(buf[a:a + 256])).digest()


def run_kernel(kind, units, payload):
    """Execute `units` work units of the given kernel kind over the payload; return hex checksum."""
    if kind not in KINDS:
        raise ValueError("unknown kernel kind %r" % kind)
    units = int(units)
    seed_digest = hashlib.sha256(payload).digest()
    block = (payload[:4096] if len(payload) >= 4096 else (payload * (4096 // max(1, len(payload)) + 1))[:4096])
    state = seed_digest
    if kind == "cpu":
        for _ in range(units):
            state = _cpu_unit(state, block)
    elif kind == "mem":
        buf = bytearray(_mem_buffer())          # private copy so repeated runs are identical
        rng = random.Random(int.from_bytes(seed_digest[:8], "big"))
        for _ in range(units):
            state = _mem_unit(state, buf, rng)
    else:  # mixed: alternate CPU, memory and compression work
        buf = bytearray(_mem_buffer())
        rng = random.Random(int.from_bytes(seed_digest[:8], "big"))
        for u in range(units):
            if u % 3 == 0:
                state = _cpu_unit(state, block)
            elif u % 3 == 1:
                state = _mem_unit(state, buf, rng)
            else:
                off = (u * 7919) % max(1, len(payload) - 16384) if len(payload) > 16384 else 0
                z = zlib.compress(payload[off:off + 16384], 6)
                state = hashlib.sha256(state + z[:64]).digest()
    return hashlib.sha256(state).hexdigest()
