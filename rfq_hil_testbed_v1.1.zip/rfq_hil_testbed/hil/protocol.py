"""Framed message protocol shared by the host and the Raspberry Pi.

Frame = 4-byte big-endian header length | UTF-8 JSON header | 4-byte payload length | payload bytes.
Every header carries the protocol version and a message type. Standard library only.
"""
import json
import socket
import struct

PROTOCOL_VERSION = "hil-1.0"
MAX_HEADER = 1 << 20          # 1 MiB
MAX_PAYLOAD = 16 << 20        # 16 MiB

TYPES = {
    "HELLO", "CONFIG", "CONFIG_ACK", "TASK", "OFFLOAD_REQUEST", "OFFLOAD_RESULT",
    "FINAL_RESULT", "PROBE_REQ", "PROBE", "PROBE_ACK", "PROBE_DONE",
    "END_RUN", "RUN_SUMMARY", "PROFILE_REQ", "PROFILE_RESULT", "BYE", "ERROR",
}


class ProtocolError(Exception):
    pass


def _recv_exact(sock, n):
    buf = bytearray()
    while len(buf) < n:
        chunk = sock.recv(min(n - len(buf), 1 << 16))
        if not chunk:
            raise ConnectionError("peer closed connection")
        buf.extend(chunk)
    return bytes(buf)


def send(sock, header, payload=b""):
    if header.get("type") not in TYPES:
        raise ProtocolError("unknown message type %r" % header.get("type"))
    header = dict(header)
    header["v"] = PROTOCOL_VERSION
    h = json.dumps(header, separators=(",", ":")).encode("utf-8")
    if len(h) > MAX_HEADER or len(payload) > MAX_PAYLOAD:
        raise ProtocolError("message too large")
    sock.sendall(struct.pack(">I", len(h)) + h + struct.pack(">I", len(payload)) + payload)


def recv(sock):
    (hl,) = struct.unpack(">I", _recv_exact(sock, 4))
    if hl > MAX_HEADER:
        raise ProtocolError("header too large")
    header = json.loads(_recv_exact(sock, hl).decode("utf-8"))
    (pl,) = struct.unpack(">I", _recv_exact(sock, 4))
    if pl > MAX_PAYLOAD:
        raise ProtocolError("payload too large")
    payload = _recv_exact(sock, pl) if pl else b""
    if header.get("v") != PROTOCOL_VERSION:
        raise ProtocolError("protocol version mismatch: %r" % header.get("v"))
    if header.get("type") not in TYPES:
        raise ProtocolError("unknown message type %r" % header.get("type"))
    return header, payload


def tune(sock):
    sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
    return sock
