"""Safety-constrained, fuzzy-guided tabular Q-learning scheduler and baseline policies.

Layers (evaluated in this order):
  1. Deterministic guard: critical (p=1) or deadline <= D_safe  -> admissible set {Local}.
  2. Mamdani fuzzy prior: offloading suitability F in [0,1] from CPU load, link RTT, payload, urgency.
  3. Tabular Q-learning over the admissible set, guided by the prior: G(s,a) = Q(s,a) + lambda*b(a).
Standard library only, so it runs unchanged on Raspberry Pi OS.
"""
import hashlib
import json
import random
import time

LOCAL, OFFLOAD = 0, 1
ACTIONS = ("Local", "Offload")

POLICIES = ("Local-Only", "Offload-All", "Rule-Only", "Fuzzy-Only", "Estimate-Greedy", "Q-Only", "Hybrid")
LEARNERS = ("Q-Only", "Hybrid")

# ---------------------------------------------------------------- normalization / discretization
BOUNDS = {"cpu": (0.0, 100.0), "rtt": (0.0, 300.0), "payload_kb": (0.0, 256.0), "urg": (0.0, 1.0)}
CPU_CUTS = (33.0, 67.0)      # % utilization
RTT_CUTS = (20.0, 80.0)      # ms
URG_CUTS = (0.33, 0.67)


def clip01(x):
    return 0.0 if x < 0.0 else (1.0 if x > 1.0 else x)


def level(x, cuts):
    return 0 if x < cuts[0] else (1 if x < cuts[1] else 2)


def urgency(deadline_ms, d_safe, d_max):
    """1 for the tightest admissible deadline, 0 for deadlines >= d_max."""
    return clip01(1.0 - (deadline_ms - d_safe) / max(1e-9, (d_max - d_safe)))


def state_index(cpu, rtt, work_cls, payload_cls, urg):
    """3^5 = 243 discrete states: CPU, RTT, work class, payload class, urgency."""
    c = level(cpu, CPU_CUTS)
    r = level(rtt, RTT_CUTS)
    u = level(urg, URG_CUTS)
    return (((c * 3 + r) * 3 + int(work_cls)) * 3 + int(payload_cls)) * 3 + u


N_STATES = 243

# ---------------------------------------------------------------- Mamdani fuzzy inference


def trimf(x, a, b, c):
    if x <= a:
        return 1.0 if a == b else 0.0
    if x >= c:
        return 1.0 if b == c else 0.0
    if x < b:
        return (x - a) / (b - a)
    return (c - x) / (c - b) if c != b else 1.0


MF = {
    "cpu": ((0, 0, 50), (25, 50, 75), (50, 100, 100)),
    "rtt": ((0, 0, 60), (30, 90, 150), (100, 300, 300)),
    "payload_kb": ((0, 0, 96), (32, 128, 224), (160, 256, 256)),
    "urg": ((0, 0, 0.4), (0.2, 0.5, 0.8), (0.6, 1.0, 1.0)),
}
OUT_MF = ((0, 0, 0.4), (0.2, 0.5, 0.8), (0.6, 1.0, 1.0))
_Y = [i / 100.0 for i in range(101)]
_OUT_TABLE = [[trimf(y, *OUT_MF[k]) for y in _Y] for k in range(3)]


def rule_consequent(c, r, p, u):
    """Expert rule generator (fixed before experiments): offloading is more suitable when the device
    is loaded, and less suitable when the link is slow, the payload is large or the task is urgent."""
    g = 1.0 * c - 1.0 * r - 0.6 * p - 0.8 * u
    if g >= 0.5:
        return 2
    if g >= -0.9:
        return 1
    return 0


RULES = [((c, r, p, u), rule_consequent(c, r, p, u))
         for c in range(3) for r in range(3) for p in range(3) for u in range(3)]   # 81 rules


def fuzzy_score(cpu, rtt, payload_kb, urg):
    x = (clip(cpu, "cpu"), clip(rtt, "rtt"), clip(payload_kb, "payload_kb"), clip(urg, "urg"))
    mu = [[trimf(x[i], *MF[name][k]) for k in range(3)] for i, name in enumerate(("cpu", "rtt", "payload_kb", "urg"))]
    act = [0.0, 0.0, 0.0]
    for (c, r, p, u), out in RULES:
        w = min(mu[0][c], mu[1][r], mu[2][p], mu[3][u])
        if w > act[out]:
            act[out] = w
    num = den = 0.0
    for j, y in enumerate(_Y):
        m = max(min(act[0], _OUT_TABLE[0][j]), min(act[1], _OUT_TABLE[1][j]), min(act[2], _OUT_TABLE[2][j]))
        num += m * y
        den += m
    return num / den if den > 0 else 0.5


def clip(x, name):
    lo, hi = BOUNDS[name]
    return lo if x < lo else (hi if x > hi else x)

# ---------------------------------------------------------------- Q-table


class QTable:
    def __init__(self, values=None):
        self.q = values if values is not None else [[0.0, 0.0] for _ in range(N_STATES)]
        self.visits = [[0, 0] for _ in range(N_STATES)]

    def to_json(self):
        return json.dumps({"q": self.q, "visits": self.visits}, separators=(",", ":"))

    def digest(self):
        return hashlib.sha256(json.dumps(self.q, separators=(",", ":")).encode()).hexdigest()

    @classmethod
    def from_json(cls, s):
        d = json.loads(s)
        t = cls(d["q"])
        t.visits = d.get("visits", t.visits)
        return t

    def update(self, s, a, r, s_next, alpha, gamma, next_admissible=(LOCAL, OFFLOAD)):
        target = r + gamma * max(self.q[s_next][b] for b in next_admissible) if gamma > 0 else r
        self.q[s][a] += alpha * (target - self.q[s][a])
        self.visits[s][a] += 1

# ---------------------------------------------------------------- estimator for the Estimate-Greedy baseline


class Estimator:
    """Online EWMA estimates used by Estimate-Greedy (and logged for every policy)."""

    def __init__(self, local_ms_per_unit):
        self.local = {(k, c): local_ms_per_unit[k] * (1.0 + 0.5 * c) for k in local_ms_per_unit for c in range(3)}
        self.remote = {k: local_ms_per_unit[k] * 0.4 for k in local_ms_per_unit}
        self.rtt = 30.0
        self.mbps = 20.0
        self.a = 0.2

    def est_local(self, kind, units, cpu):
        return self.local[(kind, level(cpu, CPU_CUTS))] * units

    def est_offload(self, kind, units, payload_bytes):
        return self.rtt + payload_bytes * 8 / (self.mbps * 1000.0) + self.remote[kind] * units

    def obs_local(self, kind, units, cpu, ms):
        if units > 0:
            key = (kind, level(cpu, CPU_CUTS))
            self.local[key] += self.a * (ms / units - self.local[key])

    def obs_rtt(self, ms):
        self.rtt += self.a * (ms - self.rtt)

    def obs_offload(self, kind, units, payload_bytes, total_ms, remote_ms):
        if units > 0 and remote_ms is not None:
            self.remote[kind] += self.a * (remote_ms / units - self.remote[kind])
        xfer = total_ms - self.rtt - (remote_ms or 0.0)
        if xfer > 0.5 and payload_bytes > 16384:
            mbps = payload_bytes * 8 / (xfer * 1000.0)
            self.mbps += self.a * (min(max(mbps, 0.5), 1000.0) - self.mbps)

# ---------------------------------------------------------------- decision


class Decision:
    __slots__ = ("action", "source", "fuzzy", "qvals", "state", "guard_ns", "fuzzy_ns", "q_ns", "total_ns", "explored")


def decide(policy, ctx, qtable, params, rng, explore_eps=0.0):
    """ctx: dict with cpu, rtt, payload_kb, urg, work_cls, payload_cls, critical, deadline_ms, kind, units, payload_bytes, est."""
    d = Decision()
    d.fuzzy = None
    d.qvals = None
    d.explored = False
    d.state = state_index(ctx["cpu"], ctx["rtt"], ctx["work_cls"], ctx["payload_cls"], ctx["urg"])
    t0 = time.perf_counter_ns()
    guarded = ctx["critical"] or ctx["deadline_ms"] <= params["d_safe_ms"]
    t1 = time.perf_counter_ns()
    d.guard_ns = t1 - t0
    d.fuzzy_ns = 0
    d.q_ns = 0

    if policy == "Local-Only":
        d.action, d.source = LOCAL, "policy"
    elif policy == "Offload-All":                      # unguarded negative control
        d.action, d.source = OFFLOAD, "policy"
    elif guarded:
        d.action, d.source = LOCAL, "guard"
    elif policy == "Rule-Only":
        d.action = OFFLOAD if (ctx["cpu"] >= params["rule_cpu"] and ctx["rtt"] <= params["rule_rtt"]) else LOCAL
        d.source = "rule"
    elif policy == "Estimate-Greedy":
        est = ctx["est"]
        lo = est.est_local(ctx["kind"], ctx["units"], ctx["cpu"])
        of = est.est_offload(ctx["kind"], ctx["units"], ctx["payload_bytes"])
        d.action, d.source = (OFFLOAD if of < lo else LOCAL), "estimate"
    else:
        tf = time.perf_counter_ns()
        if policy in ("Fuzzy-Only", "Hybrid"):
            d.fuzzy = fuzzy_score(ctx["cpu"], ctx["rtt"], ctx["payload_kb"], ctx["urg"])
        tq = time.perf_counter_ns()
        d.fuzzy_ns = tq - tf
        if policy == "Fuzzy-Only":
            d.action, d.source = (OFFLOAD if d.fuzzy > 0.5 else LOCAL), "fuzzy"
        else:
            q = qtable.q[d.state]
            lam = params["lambda"] if policy == "Hybrid" else 0.0
            f = d.fuzzy if d.fuzzy is not None else 0.5
            g = (q[0] + lam * (1.0 - f), q[1] + lam * f)
            d.qvals = [q[0], q[1]]
            if explore_eps > 0 and rng.random() < explore_eps:
                d.action, d.explored = rng.randrange(2), True
            else:
                d.action = OFFLOAD if g[1] > g[0] else LOCAL
            d.source = "learner"
        d.q_ns = time.perf_counter_ns() - tq
    d.total_ns = time.perf_counter_ns() - t0
    return d


def reward(completion_ms, deadline_ms, missed, failed, w):
    return -(w["lat"] * min(completion_ms / max(deadline_ms, 1e-6), 3.0) / 3.0
             + w["miss"] * (1.0 if missed else 0.0) + w["fail"] * (1.0 if failed else 0.0))
