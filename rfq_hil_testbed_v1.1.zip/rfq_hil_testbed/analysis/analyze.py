#!/usr/bin/env python3
"""Regenerate every table, figure and statistic from the raw run logs.

    python analysis/analyze.py results_campaign        (needs numpy, scipy, matplotlib)
"""
import collections
import glob
import json
import os
import sys

import numpy as np
from scipy import stats

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from hil import scheduler as S, workloads as W  # noqa: E402

POL = list(S.POLICIES)
REF = "Hybrid"
COL = {"Local-Only": "#8a8a86", "Offload-All": "#c9c9c4", "Rule-Only": "#eb6834", "Fuzzy-Only": "#e0a526",
       "Estimate-Greedy": "#7b5ea7", "Q-Only": "#1baf7a", "Hybrid": "#2a78d6"}
NETS = ["good", "moderate", "poor", "bursty"]
LOADS = ["low", "medium", "high"]


def load_runs(root):
    runs = []
    for fn in sorted(glob.glob(os.path.join(root, "runs", "*.jsonl"))):
        recs = [json.loads(x) for x in open(fn)]
        cfg = recs[0]
        tasks = [r for r in recs if r["rec"] == "task"]
        summ = recs[-1] if recs[-1]["rec"] == "summary" else None
        runs.append({"id": cfg["run_id"], "phase": cfg["phase"], "policy": cfg["policy"], "seed": cfg["seed"],
                     "load": cfg["load"], "net": cfg["net"], "fault": cfg.get("fault"), "cfg": cfg, "tasks": tasks,
                     "summary": summ})
    return runs


def pct(a, q):
    return float(np.percentile(a, q)) if len(a) else float("nan")


def boot_ci(d, n=10000, seed=0):
    d = np.asarray(d, float)
    rng = np.random.default_rng(seed)
    m = rng.choice(d, (n, len(d)), replace=True).mean(1)
    return float(np.percentile(m, 2.5)), float(np.percentile(m, 97.5))


def holm(ps):
    order = np.argsort(ps)
    adj = np.empty(len(ps))
    run = 0.0
    for k, i in enumerate(order):
        run = max(run, min(1.0, (len(ps) - k) * ps[i]))
        adj[i] = run
    return adj


def policy_table(runs):
    rows = {}
    for p in POL:
        T = [t for r in runs if r["policy"] == p for t in r["tasks"]]
        if not T:
            continue
        comp = np.array([t["pi"]["completion_ms"] for t in T])
        miss = np.array([t["pi"]["missed"] for t in T], float)
        crit = [t for t in T if t["task"]["critical"]]
        guarded = [t for t in T if t["guarded"]]
        dec = np.array([t["pi"]["decision_us"] for t in T])
        pol_us = np.array([t["pi"]["policy_us"] for t in T])
        rows[p] = {
            "tasks": len(T), "mean_ms": float(comp.mean()), "median_ms": pct(comp, 50), "p95_ms": pct(comp, 95),
            "p99_ms": pct(comp, 99), "miss_pct": 100 * float(miss.mean()),
            "crit_miss_pct": 100 * float(np.mean([t["pi"]["missed"] for t in crit])) if crit else float("nan"),
            "guarded_offload_pct": 100 * float(np.mean([t["host"]["offloaded"] for t in guarded])) if guarded else float("nan"),
            "offload_pct": 100 * float(np.mean([t["pi"]["action"] == "Offload" for t in T])),
            "fallback_pct": 100 * float(np.mean([t["pi"]["fallback"] for t in T])),
            "reward": float(np.mean([t["pi"]["reward"] for t in T])),
            "decision_us_median": pct(dec, 50), "decision_us_p99": pct(dec, 99),
            "policy_us_median": pct(pol_us, 50), "policy_us_p99": pct(pol_us, 99),
        }
    return rows


def paired(runs, metric):
    """Run-level paired comparison of REF against every other policy on blocks (seed, load, net[, fault])."""
    blocks = collections.defaultdict(dict)
    for r in runs:
        k = (r["seed"], r["load"], r["net"], r["fault"])
        T = r["tasks"]
        if metric == "miss":
            v = 100 * np.mean([t["pi"]["missed"] for t in T])
        elif metric == "mean_ms":
            v = np.mean([t["pi"]["completion_ms"] for t in T])
        else:
            v = -np.mean([t["pi"]["reward"] for t in T])
        blocks[k][r["policy"]] = v
    out = {}
    others = [p for p in POL if p != REF]
    ps = []
    for p in others:
        d = np.array([b[REF] - b[p] for b in blocks.values() if REF in b and p in b])
        if len(d) < 2:
            continue
        nz = d[d != 0]
        if len(nz) >= 1:
            w = stats.wilcoxon(d, zero_method="wilcox")
            pval = float(w.pvalue)
            rp = stats.rankdata(np.abs(nz))
            rbc = float((rp[nz > 0].sum() - rp[nz < 0].sum()) / rp.sum())
        else:
            pval, rbc = 1.0, 0.0
        lo, hi = boot_ci(d)
        out[p] = {"n_blocks": int(len(d)), "mean_diff": float(d.mean()), "ci": [lo, hi], "p": pval, "rank_biserial": rbc,
                  "ref_better_blocks": int((d < 0).sum()), "ref_worse_blocks": int((d > 0).sum())}
        ps.append(pval)
    adj = holm(np.array([out[p]["p"] for p in out])) if out else []
    for p, a in zip(out, adj):
        out[p]["p_holm"] = float(a)
    return out


def by_condition(runs, key):
    tab = collections.defaultdict(dict)
    for p in POL:
        for k in (NETS if key == "net" else LOADS if key == "load" else ["relaxed", "moderate", "strict", "urgent"]):
            if key == "pressure":
                T = [t for r in runs if r["policy"] == p for t in r["tasks"] if t["task"]["pressure"] == k]
            else:
                T = [t for r in runs if r["policy"] == p and r[key] == k for t in r["tasks"]]
            if T:
                tab[p][k] = 100 * float(np.mean([t["pi"]["missed"] for t in T]))
    return tab


def integrity(runs, env):
    inv = collections.Counter()
    for r in runs:
        if r["summary"]:
            inv.update(r["summary"]["integrity"])
    # workload equivalence: identical task executed locally and remotely must give identical checksums
    seen, agree, disagree = {}, 0, 0
    for r in runs:
        for t in r["tasks"]:
            if t["pi"]["fallback"]:
                continue
            k = (t["task"]["task_seed"], t["task"]["kind"], t["task"]["units"], t["task"]["payload_bytes"])
            c = t["pi"]["checksum"]
            where = t["pi"]["action"]
            if k in seen and seen[k][1] != where:
                if seen[k][0] == c:
                    agree += 1
                else:
                    disagree += 1
            seen.setdefault(k, (c, where))
    seqs_ok = all([t["task"]["seq"] for t in r["tasks"]] == list(range(len(r["tasks"]))) for r in runs)
    return {"label": env.get("label"), "runs": len(runs), "tasks": sum(len(r["tasks"]) for r in runs),
            **{k: int(v) for k, v in inv.items()}, "sequence_continuous": bool(seqs_ok),
            "cross_endpoint_checksum_agree": agree, "cross_endpoint_checksum_disagree": disagree}


def fig_bars(tab, path, key, ylabel):
    ps = [p for p in POL if p in tab]
    fig, ax = plt.subplots(figsize=(7.2, 3.4), dpi=200)
    ax.bar(range(len(ps)), [tab[p][key] for p in ps], color=[COL[p] for p in ps])
    for i, p in enumerate(ps):
        ax.text(i, tab[p][key], "%.1f" % tab[p][key], ha="center", va="bottom", fontsize=7.5)
    ax.set_xticks(range(len(ps)))
    ax.set_xticklabels(ps, rotation=20, ha="right", fontsize=8)
    ax.set_ylabel(ylabel, fontsize=9)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    fig.tight_layout()
    fig.savefig(path)
    plt.close(fig)


def fig_ecdf(runs, path):
    fig, ax = plt.subplots(figsize=(7.2, 3.6), dpi=200)
    for p in POL:
        c = np.sort([t["pi"]["completion_ms"] / t["task"]["deadline_ms"] for r in runs if r["policy"] == p for t in r["tasks"]])
        if len(c):
            ax.plot(c, np.arange(1, len(c) + 1) / len(c), color=COL[p], lw=1.6 if p in (REF, "Q-Only") else 1.1, label=p)
    ax.axvline(1.0, color="#555", lw=0.8, ls="--")
    ax.set_xscale("log")
    ax.set_xlabel("Completion time / deadline (log scale; > 1 is a miss)", fontsize=9)
    ax.set_ylabel("Fraction of tasks", fontsize=9)
    ax.legend(fontsize=7, frameon=False, ncol=2)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    fig.tight_layout()
    fig.savefig(path)
    plt.close(fig)


def fig_heat(runs, path):
    ps = [p for p in POL if p != "Offload-All"]
    conds = [(l, n) for l in LOADS for n in NETS]
    M = np.full((len(ps), len(conds)), np.nan)
    for i, p in enumerate(ps):
        for j, (l, n) in enumerate(conds):
            T = [t for r in runs if r["policy"] == p and r["load"] == l and r["net"] == n for t in r["tasks"]]
            if T:
                M[i, j] = 100 * np.mean([t["pi"]["missed"] for t in T])
    fig, ax = plt.subplots(figsize=(8.2, 3.4), dpi=200)
    im = ax.imshow(M, cmap="Blues", aspect="auto")
    for i in range(M.shape[0]):
        for j in range(M.shape[1]):
            if not np.isnan(M[i, j]):
                ax.text(j, i, "%.0f" % M[i, j], ha="center", va="center", fontsize=6.5,
                        color="white" if M[i, j] > np.nanmax(M) * 0.6 else "#222")
    ax.set_yticks(range(len(ps)))
    ax.set_yticklabels(ps, fontsize=7.5)
    ax.set_xticks(range(len(conds)))
    ax.set_xticklabels(["%s\n%s" % (l, n) for l, n in conds], fontsize=6.5)
    fig.colorbar(im, ax=ax, label="Deadline-miss rate (%)", shrink=0.85)
    fig.tight_layout()
    fig.savefig(path)
    plt.close(fig)


def fig_learning(runs, path):
    fig, ax = plt.subplots(figsize=(6.4, 3.0), dpi=200)
    for p in S.LEARNERS:
        R = [r for r in runs if r["phase"] == "calibration" and r["policy"] == p]
        R.sort(key=lambda r: -r["cfg"]["epsilon"])          # epsilon decays monotonically with run order
        y = [np.mean([t["pi"]["reward"] for t in r["tasks"] if t["pi"]["source"] == "learner"] or [np.nan]) for r in R]
        if y:
            k = 6
            ys = np.convolve(np.nan_to_num(y, nan=np.nanmean(y)), np.ones(k) / k, mode="valid") if len(y) >= k else y
            ax.plot(range(len(ys)), ys, color=COL[p], label=p)
    ax.set_xlabel("Calibration run (moving average of 6)", fontsize=9)
    ax.set_ylabel("Mean reward of learner decisions", fontsize=9)
    ax.legend(fontsize=8, frameon=False)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    fig.tight_layout()
    fig.savefig(path)
    plt.close(fig)


def fig_faults(ftab, path):
    faults = list(ftab)
    ps = [p for p in POL if p != "Offload-All"]
    fig, ax = plt.subplots(figsize=(7.6, 3.4), dpi=200)
    w = 0.8 / len(ps)
    for i, p in enumerate(ps):
        ax.bar(np.arange(len(faults)) + (i - len(ps) / 2 + 0.5) * w, [ftab[f].get(p, np.nan) for f in faults], w,
               color=COL[p], label=p)
    ax.set_xticks(range(len(faults)))
    ax.set_xticklabels(faults, fontsize=8)
    ax.set_ylabel("Deadline-miss rate in fault window (%)", fontsize=8.5)
    ax.legend(fontsize=6.5, frameon=False, ncol=3)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    fig.tight_layout()
    fig.savefig(path)
    plt.close(fig)


def main(root):
    env = json.load(open(os.path.join(root, "environment.json")))
    out = os.path.join(root, "analysis")
    os.makedirs(out, exist_ok=True)
    runs = load_runs(root)
    main_runs = [r for r in runs if r["phase"] == "main"]
    fault_runs = [r for r in runs if r["phase"] == "faults"]
    res = {"environment": {"label": env.get("label"), "pi_model": env["pi"]["hw"].get("model"),
                           "pi_kernel": env["pi"]["hw"].get("kernel"), "pi_python": env["pi"]["hw"].get("python"),
                           "pi_governor": env["pi"]["hw"].get("governor"), "host": env["host"],
                           "calibration_ms_per_unit": env["pi"]["calibration"]},
           "integrity": integrity(runs, env),
           "main": policy_table(main_runs),
           "paired_miss": paired(main_runs, "miss"), "paired_mean_ms": paired(main_runs, "mean_ms"),
           "paired_cost": paired(main_runs, "cost"),
           "miss_by_net": by_condition(main_runs, "net"), "miss_by_load": by_condition(main_runs, "load"),
           "miss_by_pressure": by_condition(main_runs, "pressure")}
    ftab = {}
    for f in sorted({r["fault"] for r in fault_runs}):
        ftab[f] = {}
        for p in POL:
            T = [t for r in fault_runs if r["fault"] == f and r["policy"] == p for t in r["tasks"] if t["host"]["fault_active"]]
            if T:
                ftab[f][p] = 100 * float(np.mean([t["pi"]["missed"] for t in T]))
        res.setdefault("fault_fallbacks", {})[f] = {p: int(sum(t["pi"]["fallback"] for r in fault_runs if r["fault"] == f and r["policy"] == p for t in r["tasks"])) for p in POL}
    res["faults_miss_in_window"] = ftab
    if fault_runs:
        res["paired_faults_miss"] = paired(fault_runs, "miss")
    prof = os.path.join(root, "profile.json")
    if os.path.exists(prof):
        res["profile"] = json.load(open(prof))
    # calibration / learning
    for p in S.LEARNERS:
        R = [r for r in runs if r["phase"] == "calibration" and r["policy"] == p]
        if R:
            last = max(R, key=lambda r: -r["cfg"].get("epsilon", 0))
            res.setdefault("learning", {})[p] = {"runs": len(R), "transitions": sum(1 for r in R for t in r["tasks"] if t["pi"]["source"] == "learner"),
                                                 "states_visited": last["summary"]["pi"].get("q_visited") if last["summary"] else None}
    q_hashes = {r["policy"]: r["cfg"]["ack"]["q_hash"] for r in main_runs if r["policy"] in S.LEARNERS}
    res["frozen_q_hashes"] = q_hashes
    res["temperature_c"] = {"max": max([t["pi"]["temp_c"] or 0 for r in runs for t in r["tasks"]] or [0]),
                            "throttled_flags": sorted({str(r["summary"]["pi"].get("throttled")) for r in runs if r["summary"]})}
    en = os.path.join(root, "energy_readings.jsonl")
    if os.path.exists(en):
        E = [json.loads(x) for x in open(en)]
        idle = next((e for e in E if e["block"] == "IDLE"), None)
        res["energy"] = {}
        for e in E:
            mwh = e["mwh_after"] - e["mwh_before"]
            row = {"mWh": mwh, "duration_s": e["duration_s"], "mean_W": mwh * 3.6 / e["duration_s"]}
            if idle and e["block"] != "IDLE":
                idle_w = (idle["mwh_after"] - idle["mwh_before"]) * 3.6 / idle["duration_s"]
                ntask = json.load(open(os.path.join(root, "environment.json")))["config"]["energy"]["tasks"]
                row["mJ_per_task_above_idle"] = (mwh * 3.6 - idle_w * e["duration_s"]) * 1000 / ntask
            res["energy"][e["block"]] = row
    json.dump(res, open(os.path.join(out, "summary.json"), "w"), indent=1)

    if res["main"]:
        fig_bars(res["main"], os.path.join(out, "fig_miss_rate.png"), "miss_pct", "Deadline-miss rate (%)")
        fig_bars(res["main"], os.path.join(out, "fig_p95.png"), "p95_ms", "p95 completion time (ms)")
        fig_ecdf(main_runs, os.path.join(out, "fig_ecdf.png"))
        fig_heat(main_runs, os.path.join(out, "fig_heatmap.png"))
    fig_learning(runs, os.path.join(out, "fig_learning.png"))
    if ftab:
        fig_faults(ftab, os.path.join(out, "fig_faults.png"))
    print(json.dumps({"integrity": res["integrity"], "main": {p: {k: round(v, 2) for k, v in d.items() if k in
                     ("miss_pct", "mean_ms", "p95_ms", "crit_miss_pct", "guarded_offload_pct", "offload_pct", "policy_us_p99")}
                     for p, d in res["main"].items()}}, indent=1))


if __name__ == "__main__":
    main(sys.argv[1])
