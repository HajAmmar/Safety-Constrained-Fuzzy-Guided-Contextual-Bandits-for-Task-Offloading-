"""Unit tests: python3 -m unittest discover -s tests -v   (run on both devices before the campaign)."""
import os
import random
import socket
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from hil import protocol, scheduler as S, workloads as W  # noqa: E402

PARAMS = {"d_safe_ms": 30.0, "d_max_ms": 400.0, "lambda": 0.3, "rule_cpu": 60.0, "rule_rtt": 40.0,
          "offload_timeout_ms": 600.0}


def ctx(rng, critical=False, deadline=200.0):
    est = S.Estimator({"cpu": 1.0, "mem": 1.0, "mixed": 1.0})
    return {"cpu": rng.uniform(0, 100), "rtt": rng.uniform(0, 300), "payload_kb": rng.uniform(0, 256),
            "urg": rng.random(), "work_cls": rng.randrange(3), "payload_cls": rng.randrange(3),
            "critical": critical, "deadline_ms": deadline, "kind": "cpu", "units": 10, "payload_bytes": 65536, "est": est}


class TestProtocol(unittest.TestCase):
    def test_roundtrip(self):
        a, b = socket.socketpair()
        protocol.send(a, {"type": "TASK", "seq": 3, "x": [1, 2]}, b"abc")
        h, p = protocol.recv(b)
        self.assertEqual((h["seq"], h["x"], p), (3, [1, 2], b"abc"))
        a.close(), b.close()

    def test_unknown_type_rejected(self):
        a, b = socket.socketpair()
        with self.assertRaises(protocol.ProtocolError):
            protocol.send(a, {"type": "NOPE"})
        a.close(), b.close()


class TestWorkloads(unittest.TestCase):
    def test_deterministic_and_kind_specific(self):
        p = W.make_payload(42, 20000)
        self.assertEqual(p, W.make_payload(42, 20000))
        for k in W.KINDS:
            self.assertEqual(W.run_kernel(k, 3, p), W.run_kernel(k, 3, p))
        self.assertEqual(len({W.run_kernel(k, 3, p) for k in W.KINDS}), 3)
        self.assertNotEqual(W.run_kernel("cpu", 3, p), W.run_kernel("cpu", 4, p))


class TestScheduler(unittest.TestCase):
    def test_guard_invariant(self):
        """Proposition 1: guarded tasks are never offloaded by any guarded policy, any Q, any epsilon."""
        rng = random.Random(1)
        for _ in range(3000):
            q = S.QTable([[rng.uniform(-5, 5), rng.uniform(-5, 5)] for _ in range(S.N_STATES)])
            crit = rng.random() < 0.5
            dl = rng.uniform(1, 30) if not crit else rng.uniform(1, 500)
            for pol in S.POLICIES:
                if pol in ("Offload-All",):
                    continue
                d = S.decide(pol, ctx(rng, crit, dl), q, PARAMS, rng, explore_eps=1.0)
                self.assertEqual(d.action, S.LOCAL, pol)

    def test_rule_base_and_score(self):
        self.assertEqual(len(S.RULES), 81)
        rng = random.Random(2)
        for _ in range(2000):
            f = S.fuzzy_score(rng.uniform(-10, 120), rng.uniform(-5, 500), rng.uniform(0, 400), rng.uniform(-1, 2))
            self.assertTrue(0.0 <= f <= 1.0)
        self.assertGreater(S.fuzzy_score(95, 5, 8, 0.1), S.fuzzy_score(5, 250, 250, 0.9))

    def test_state_space(self):
        rng = random.Random(3)
        seen = {S.state_index(rng.uniform(0, 100), rng.uniform(0, 300), rng.randrange(3), rng.randrange(3), rng.random())
                for _ in range(50000)}
        self.assertTrue(seen <= set(range(243)))
        self.assertEqual(len(seen), 243)

    def test_reward_bounds_and_update(self):
        w = {"lat": 1.0, "miss": 1.0, "fail": 1.0}
        self.assertAlmostEqual(S.reward(0.0, 100, False, False, w), 0.0)
        self.assertGreaterEqual(S.reward(1e9, 100, True, True, w), -3.0)
        q = S.QTable()
        q.update(5, 1, -1.0, 5, 0.5, 0.0)
        self.assertAlmostEqual(q.q[5][1], -0.5)
        self.assertEqual(S.QTable.from_json(q.to_json()).digest(), q.digest())


if __name__ == "__main__":
    unittest.main()
