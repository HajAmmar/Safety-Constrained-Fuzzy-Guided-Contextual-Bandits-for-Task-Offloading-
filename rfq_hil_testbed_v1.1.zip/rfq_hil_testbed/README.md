# Rule–Fuzzy–Q HIL testbed

Two-device hardware-in-the-loop testbed for a safety-constrained, fuzzy-guided tabular Q-learning
offloading controller. The **Raspberry Pi** runs the controller, telemetry and Local execution; a
separate **host computer** generates seeded tasks, emulates the network, executes offloaded tasks and
keeps the authoritative log. Standard-library Python only on both devices (Python ≥ 3.9 on the Pi,
Python ≥ 3.11 on a Windows host for accurate sub-millisecond sleeps).

```
hil/protocol.py      framed TCP protocol (versioned JSON header + binary payload)
hil/scheduler.py     guard, 81-rule Mamdani FIS, 243x2 Q-table, 7 policies
hil/workloads.py     deterministic CPU / memory / mixed kernels with SHA-256 checksum
hil/telemetry.py     /proc and /sys telemetry, background-load generator
pi_controller.py     runs on the Raspberry Pi
host_orchestrator.py runs on the host (resumable; completed runs are skipped)
config/experiment.json  all parameters, seeds, network regimes, faults
analysis/analyze.py  regenerates every table, figure and statistic from the raw logs
tests/test_hil.py    unit tests (run on both devices)
```

## Run

1. Copy this folder to both devices. Run `python3 -m unittest discover -s tests` on each.
2. Host: `python host_orchestrator.py --profile pilot --phase all` (pilot, about 20 min).
3. Pi: `python3 pi_controller.py --host <HOST_IP>` (first start calibrates the kernels for ~30 s).
4. Full campaign: host `python host_orchestrator.py --phase all` (about 4 h), Pi command unchanged.
5. Optional energy blocks with a USB-C power meter: host `python host_orchestrator.py --phase energy`.
6. Analysis: `python analysis/analyze.py results_campaign` (needs numpy, scipy, matplotlib).

Phases: `profile` (isolated per-layer controller timing on the Pi), `calibration` (online learning
for Q-Only and Hybrid on separate seeds; tables are then frozen), `main` (7 policies × 3 load levels
× 4 network regimes × 10 paired seeds, policy order randomized per block), `faults` (link outage, host
slowdown, corrupted responses, loss burst).

Every run file is hashed into `manifest.jsonl`. `environment.json` labels the campaign
`physical-hil` only when the Pi connects from a different IP address than the host.
